-- AlterTable
ALTER TABLE "Url" ADD COLUMN     "vanity" TEXT;
