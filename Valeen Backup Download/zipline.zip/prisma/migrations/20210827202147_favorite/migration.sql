-- AlterTable
ALTER TABLE "Image" ADD COLUMN     "favorite" BOOLEAN NOT NULL DEFAULT false;
