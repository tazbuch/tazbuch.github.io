-- AlterTable
ALTER TABLE "User" ADD COLUMN     "totpSecret" TEXT;
