-- AlterTable 
ALTER TABLE "Stats" RENAME COLUMN "created_at" TO "createdAt";
