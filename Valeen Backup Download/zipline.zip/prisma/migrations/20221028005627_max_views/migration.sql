-- AlterTable
ALTER TABLE "Image" ADD COLUMN     "maxViews" INTEGER;
