-- AlterTable
ALTER TABLE "Image" ADD COLUMN     "password" TEXT;
