-- AlterTable
ALTER TABLE "Url" RENAME COLUMN "created_at" TO "createdAt";