-- AlterTable
ALTER TABLE "Image" ADD COLUMN     "expires_at" TIMESTAMP(3);
