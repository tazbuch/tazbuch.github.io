-- AlterEnum
ALTER TYPE "OauthProviders" ADD VALUE 'GOOGLE';
