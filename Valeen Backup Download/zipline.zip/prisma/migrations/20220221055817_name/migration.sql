-- AlterEnum
ALTER TYPE "ImageFormat" ADD VALUE 'NAME';
