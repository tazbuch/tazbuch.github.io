-- AlterTable
ALTER TABLE "Image" ADD COLUMN     "embed" BOOLEAN NOT NULL DEFAULT false;
