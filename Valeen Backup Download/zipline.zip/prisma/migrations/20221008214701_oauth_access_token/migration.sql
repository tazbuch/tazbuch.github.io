-- AlterTable
ALTER TABLE "User" ADD COLUMN     "oauthAccessToken" TEXT;
