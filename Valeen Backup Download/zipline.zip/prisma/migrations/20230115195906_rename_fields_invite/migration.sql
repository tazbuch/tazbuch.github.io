-- AlterTable
ALTER TABLE "Invite" RENAME COLUMN "created_at" TO "createdAt";

-- AlterTable
ALTER TABLE "Invite" RENAME COLUMN "expires_at" TO "expiresAt";