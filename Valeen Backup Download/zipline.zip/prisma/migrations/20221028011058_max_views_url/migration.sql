-- AlterTable
ALTER TABLE "Url" ADD COLUMN     "maxViews" INTEGER;
