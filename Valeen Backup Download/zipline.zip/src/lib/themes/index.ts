import { MantineThemeOverride } from '@mantine/core';

export default function createTheme(o: MantineThemeOverride) {
  return o;
}
