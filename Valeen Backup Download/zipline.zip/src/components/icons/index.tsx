import ShareXIcon from './ShareXIcon';
import FlameshotIcon from './FlameshotIcon';

export { ShareXIcon, FlameshotIcon };
